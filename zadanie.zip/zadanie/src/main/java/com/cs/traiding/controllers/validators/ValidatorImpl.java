package com.cs.traiding.controllers.validators;

import com.cs.traiding.controllers.datamodel.ResponseDTO;
import com.cs.traiding.controllers.datamodel.TradeDTO;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import static com.cs.traiding.controllers.datamodel.StatusDTO.createStatus;
import static com.cs.traiding.controllers.datamodel.constans.TradeType.Forward;
import static com.cs.traiding.controllers.datamodel.constans.TradeType.Spot;
import static com.cs.traiding.controllers.datamodel.constans.TradeType.VanillaOption;
import static com.cs.traiding.controllers.validators.PureValidators.*;
import static java.util.Arrays.asList;
import static reactor.core.publisher.Flux.merge;

@Component
public class ValidatorImpl implements Validator {

    @Override
    public Flux<ResponseDTO> validate(Flux<TradeDTO> tradeDTOFlux) {
        final Flux<ResponseDTO> allTrades =
                tradeDTOFlux
                        .map(trade -> new ResponseDTO(trade, createStatus()))
                        .map(trade -> validateBeforeTradeDate(trade))
                        .map(trade -> validateOnBuissnesDate(trade))
                        .map(trade -> validateCounterParty(trade, asList("PLUTO1", "PLUTO2")))
                        .map(trade -> validateCurrencyCode(trade));

        return merge(validateSpot(allTrades), validateOptions(allTrades))
                .map(trade -> {
                            trade.statusDTO.changeStatusToInvalidIfErrorsExist();
                            return trade;
                        }
                )
                ;
    }

    private Flux<ResponseDTO> validateOptions(Flux<ResponseDTO> allTrades) {
        return allTrades
                .filter(trade -> trade.isType(VanillaOption))
                .map(trade -> validateStyle(trade, asList("American", "European")))
                .map(trade -> validateExpieryDate(trade))
                .map(trade -> validateAmericanStyle(trade));
    }

    private Flux<ResponseDTO> validateSpot(Flux<ResponseDTO> allTrades) {
        return allTrades
                .filter(trade -> trade.isType(Forward, Spot))
                .map(trade -> valueDateAgainstProductType(trade))
                ;
    }
}
