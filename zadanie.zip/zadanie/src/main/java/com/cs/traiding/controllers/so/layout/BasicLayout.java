package com.cs.traiding.controllers.so.layout;

import java.awt.*;
import java.util.HashMap;

public class BasicLayout {
    private HashMap<String, ScreenElement> screenElements;

    public BasicLayout() {
        screenElements = new HashMap<>();
        screenElements.put("BACKGROUND", new ScreenElement());
        screenElements.put("BOXONE", new ScreenElement());
        screenElements.put("BOXTWO", new ScreenElement());
    }

    public HashMap<String, ScreenElement> getScreenElements() {
        return screenElements;
    }

    public ScreenElement getScreenElement(String elementName) {
        return screenElements.get(elementName);
    }

    public void draw(Canvas canvas) {
        for (ScreenElement screenElement: screenElements.values()) {
            screenElement.draw(canvas);
        }
    }
}
