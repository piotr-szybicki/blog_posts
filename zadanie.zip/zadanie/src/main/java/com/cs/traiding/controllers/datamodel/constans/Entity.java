package com.cs.traiding.controllers.datamodel.constans;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum Entity {

    @JsonProperty("CS Zurich")
    CS_ZURICH;

}
