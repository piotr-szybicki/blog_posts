package com.cs.traiding.controllers.validators;

import com.cs.traiding.controllers.datamodel.TradeDTO;
import com.cs.traiding.controllers.datamodel.constans.TradeType;
import com.google.gson.*;
import org.junit.Test;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import reactor.core.publisher.*;
import reactor.util.function.Tuple2;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.BaseStream;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.lang.Long.valueOf;
import static java.lang.String.valueOf;
import static java.lang.Thread.sleep;
import static java.util.Collections.synchronizedSet;
import static java.util.Collections.unmodifiableList;
import static java.util.Comparator.comparing;
import static java.util.UUID.randomUUID;
import static java.util.stream.Collectors.toList;
import static reactor.core.publisher.Flux.*;

public class ValidatorImplTest {

    @Test
    public void zipWith() throws FileNotFoundException, InterruptedException {

        just(create())
                .zipWith(
                        generate((Consumer<SynchronousSink<UUID>>) generator -> generator.next(randomUUID())))
                .groupBy(tuple -> tuple.getT1().type)
                .flatMap(list -> list.groupBy((element) -> element.getT1().direction))
                .flatMap(Flux::collectList)
                .subscribe(System.out::println)
        ;

        sleep(1000);
    }

    @Test
    public void zipWithCombine() throws FileNotFoundException, InterruptedException {

        just(create())
                .zipWith(
                        generate((Consumer<SynchronousSink<UUID>>) generator -> generator.next(randomUUID())))
                .groupBy(tuple -> tuple.getT1().type)
                .flatMap(list -> gorupByDirection(list))
                .flatMap(list -> list)
                .map(tuple -> tuple.getT1())
                .subscribe(System.out::println)
        ;

        sleep(1000);
    }

    @Test
    public void createSink() throws InterruptedException {
        Flux<Long> interval = Flux.interval(Duration.ofMillis(10));
        DirectProcessor<String> hot = DirectProcessor
                .create();

        hot.log()
                .subscribe((t) -> {
                    System.out.println("1: " + t);
                });

        hot
                .log()
                .subscribe((t) -> {
                    System.out.println("2: " + t);
                });


        interval.subscribe((t) -> {
            hot.onNext(valueOf(t));
        });


        Thread.sleep(1000);

    }

    @Test
    public void window() throws FileNotFoundException, InterruptedException {
        ConnectableFlux<TradeDTO> just = just(create())
                .sort(comparing(t1 -> t1.customer))
                .publish();

        just
                .window(just
                        .map(t -> t.customer)
                        .distinct()
                        .skip(1))
                .subscribe(t -> t.collectList()
                        .subscribe(System.out::println));

        just.connect();
        sleep(1000);
    }

    @Test
    public void distinct() throws FileNotFoundException, InterruptedException {
        Flux<TradeDTO> just = just(create());

        just.map(t -> t.customer)
                .distinct()
                .collectList()
                .subscribe(System.out::println);

        sleep(1000);
    }

    @Test
    public void customCollector() throws FileNotFoundException {
        List<TradeDTO> collect = just(create())
                .collect(Collector.of(
                        () -> new ArrayList<TradeDTO>(),
                        (collection, trade) -> collection.add(trade),
                        (tradeDTOS, tradeDTOS2) -> {
                            tradeDTOS.addAll(tradeDTOS2);
                            return tradeDTOS;
                        },
                        (list) -> unmodifiableList(list)
                )).block();
    }

    @Test
    public void usingExpand() {

        Request innerData = new Request(null);
        Request middleData = new Request(innerData);
        Request rootData = new Request(middleData);

        Mono.just(rootData)
                .expand(t -> Mono.justOrEmpty(t.nextPage))
                .flatMap(t -> Flux.fromIterable(t.items))
                .subscribe(System.out::println);

    }

    @Test
    public void requiresNotNull() {

        List<String> list = new ArrayList<>();
        list.add(UUID.randomUUID().toString());
        list.add(UUID.randomUUID().toString());
        list.add(null);

        List<String> collect = list.stream().peek(
                Objects::requireNonNull
        ).collect(toList())
                .stream()
                .map((t) -> "1")
                .collect(toList());

        System.out.println(collect);
    }

    @Test
    public void reactiveParser() throws InterruptedException {
        ConnectableFlux<String> letters = Flux.create((Consumer<? super FluxSink<String>>) t -> {
            char[] chars = "sfdsfsdf/sdf/sdfs/dfsdfsd/fsd/fsd/fs/df/sdf".toCharArray();
            for (char c : chars) {
                t.next(String.valueOf(c));
            }
        }).publish();

        letters
                .window(
                        letters.filter(t -> t.equals("/"))
                )
                .flatMap(t -> t.collectList())
                .map(t -> t.stream().collect(Collectors.joining()))
                .subscribe(t -> {
                    System.out.println(t);
                });

        letters.connect();
    }

    public static class Request {
        List<String> items = new ArrayList<>();
        Request nextPage;

        public Request(Request nextPage) {
            this.items.add(UUID.randomUUID().toString());
            this.items.add(UUID.randomUUID().toString());
            this.nextPage = nextPage;
        }
    }

    @Test
    public void fromCallable() {
        Mono.fromCallable(() -> createMono())
                .flatMap((optional) -> optional.map(Mono::just).orElseGet(Mono::empty))
                .subscribe();
    }

    private Optional<String> createMono() {
        return Optional.empty();
    }

    @Test
    public void customSpliterator() throws FileNotFoundException {
        just(create())
                .groupBy((trade) -> trade.type)
                .parallel()
                .as((tradeTypes) -> {
                    return "";
                })
        ;
    }

    @Test
    public void mergeMonos() throws InterruptedException {
        Mono<Long> delay1 = Mono.delay(Duration.ofMillis(1000));
        Mono<Long> delay2 = Mono.delay(Duration.ofMillis(2000));

        List<Mono<Long>> listOfMonos = new ArrayList<>();

        listOfMonos.add(delay1);
        listOfMonos.add(delay2);
        long sTime = System.currentTimeMillis();
        Flux.merge(listOfMonos)
                .filter((t) -> t != null)
                .take(1)
                .subscribe(t -> {
                    long eTime = System.currentTimeMillis();
                    System.out.println(eTime - sTime + " -> " + t);
                });

        Thread.sleep(3000);
    }

    private Flux<GroupedFlux<String, Tuple2<TradeDTO, UUID>>> gorupByDirection(GroupedFlux<TradeType, Tuple2<TradeDTO, UUID>> list) {
        return list.groupBy((element) -> element.getT1().direction);
    }

    private TradeDTO[] create() throws FileNotFoundException {
        Gson g = new GsonBuilder()
                .registerTypeAdapter(LocalDate.class, deser)
                .create();
        FileReader jsonFile = new FileReader("trades.json");
        TradeDTO[] tradeDTOS = g.fromJson(jsonFile, TradeDTO[].class);
        return tradeDTOS;
    }

    JsonDeserializer<LocalDate> deser = new JsonDeserializer<LocalDate>() {
        @Override
        public LocalDate deserialize(JsonElement json, Type typeOfT,
                                     JsonDeserializationContext context) throws JsonParseException {
      s      return json == null ? null : LocalDate.parse(json.getAsString(), DateTimeFormatter.ofPattern("yyyy-mm-DD"));
        }
    };
}