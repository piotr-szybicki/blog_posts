package com.cs.traiding.controllers.validators;

import com.cs.traiding.controllers.datamodel.ResponseDTO;
import com.cs.traiding.controllers.datamodel.TradeDTO;
import reactor.core.publisher.Flux;

public interface Validator {

    Flux<ResponseDTO> validate(Flux<TradeDTO> tradeDTOFlux);
}
