package com.cs.traiding.controllers.validators;

import com.cs.traiding.controllers.datamodel.ResponseDTO;

import java.time.DayOfWeek;
import java.util.List;

import static java.time.DayOfWeek.*;
import static java.util.Currency.getAvailableCurrencies;

public class PureValidators {

    public static ResponseDTO validateBeforeTradeDate(ResponseDTO tradeResponse) {

        if(tradeResponse.valueDate() == null){
            tradeResponse.statusDTO.addRreason("value date cannot be null");
            return tradeResponse;
        }

        if (tradeResponse.valueDate().isBefore(tradeResponse.tradeDate())) {
            tradeResponse.statusDTO.addRreason("value date cannot be before trade date");
        }
        return tradeResponse;
    }

    public static ResponseDTO validateOnBuissnesDate(ResponseDTO tradeResponse) {

        if(tradeResponse.valueDate() == null){
            return tradeResponse;
        }

        final DayOfWeek valueDay = from(tradeResponse.valueDate());
        if (SATURDAY.equals(valueDay) || SUNDAY.equals(valueDay)) {
            tradeResponse.statusDTO.addRreason("value date cannot fall on weekend or non-working day for currency");
        }
        return tradeResponse;
    }

    public static ResponseDTO validateCounterParty(ResponseDTO tradeResponse, List<String> validCounterPartis) {

        if (validCounterPartis
                .stream()
                .noneMatch(customer -> customer.equals(tradeResponse.counterParty()))) {

            tradeResponse.statusDTO.addRreason("the counterparty is not one of the supported ones");
        }

        return tradeResponse;
    }

    public static ResponseDTO validateCurrencyCode(ResponseDTO tradeResponse) {
        if(getAvailableCurrencies()
                .stream()
                .noneMatch((ccCode)-> ccCode.getCurrencyCode().equals(tradeResponse.currencyPairPrimary()))){
            tradeResponse.statusDTO.addRreason("primary currency in a pair not valid");
        }

        if(getAvailableCurrencies()
                .stream()
                .noneMatch((ccCode)-> ccCode.getCurrencyCode().equals(tradeResponse.currencyPairSecondary()))){
            tradeResponse.statusDTO.addRreason("second currency in a pair not valid");
        }

        return tradeResponse;
    }

    public static ResponseDTO validateStyle(ResponseDTO tradeResponse, List<String> validStyles) {
        if (validStyles
                .stream()
                .noneMatch(style -> style.equals(tradeResponse.styleOrEmpty()))) {

            tradeResponse.statusDTO.addRreason("the style is not one of the supported ones");
        }
        return tradeResponse;
    }

    public static ResponseDTO validateExpieryDate(ResponseDTO responseDTOSignal) {
        return responseDTOSignal;
    }

    public static ResponseDTO validateAmericanStyle(ResponseDTO responseDTO) {
        return responseDTO;
    }

    public static ResponseDTO valueDateAgainstProductType(ResponseDTO responseDTO) {
        return responseDTO;
    }
}
