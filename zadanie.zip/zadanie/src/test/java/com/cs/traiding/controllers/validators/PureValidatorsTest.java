package com.cs.traiding.controllers.validators;

import com.cs.traiding.controllers.datamodel.ResponseDTO;
import com.cs.traiding.controllers.datamodel.StatusDTO;
import com.cs.traiding.controllers.datamodel.TradeDTO;
import org.junit.Test;

import java.time.LocalDate;

import static com.cs.traiding.controllers.datamodel.constans.Entity.CS_ZURICH;
import static com.cs.traiding.controllers.datamodel.constans.TradeStatus.INVALID;
import static com.cs.traiding.controllers.datamodel.constans.TradeStatus.VALID;
import static java.time.LocalDate.now;
import static java.time.LocalDate.of;
import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;

public class PureValidatorsTest {

    final LocalDate tuesday = of(2018, 10, 30);
    final LocalDate monday = of(2018, 10, 29);
    final LocalDate sunday = of(2018, 10, 28);

    @Test
    public void validateCounterParty_validCustomer() throws Exception {

        final TradeDTO tradeDTO = new TradeDTO("PLUTO1","",null,"",
                now(),"","",
                "",monday, CS_ZURICH,"","","","");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateCounterParty(dto, asList("PLUTO1"));

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).isEmpty();
        assertThat(validated.statusDTO.status).isEqualTo(VALID);
    }

    @Test
    public void validateCounterParty_invalidCustomer() throws Exception {

        final TradeDTO tradeDTO = new TradeDTO("PLUTO1","",null,"", now(),"","",
                "",monday, CS_ZURICH,"","","","");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateCounterParty(dto, asList("PLUTO2"));

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(1);
        assertThat(validated.statusDTO.status).isEqualTo(INVALID);
    }

    @Test
    public void validateOnBuissnesDate_valueDateOnSunday() throws Exception {

        final TradeDTO tradeDTO = new TradeDTO("PLUTO1","",null,"", now(),"","",
                "",sunday, CS_ZURICH,"","","","");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateOnBuissnesDate(dto);

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(1);
        assertThat(validated.statusDTO.status).isEqualTo(INVALID);
    }

    @Test
    public void validateValueDateBeforeTradeDate_testTradeAfterValueDate() throws Exception {
        final TradeDTO tradeDTO = new TradeDTO("PLUTO1","",null,"", tuesday,"","",
                "", monday, CS_ZURICH,"","","","");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateBeforeTradeDate(dto);

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(1);
        assertThat(validated.statusDTO.status).isEqualTo(INVALID);

    }

    @Test
    public void validateCurrencyCode_validCurrencyPair(){
        final TradeDTO tradeDTO = new TradeDTO("","EURUSD",null,"", tuesday,"","",
                "", monday, CS_ZURICH,"","","USD","USD");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateCurrencyCode(dto);

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(0);
        assertThat(validated.statusDTO.status).isEqualTo(VALID);
    }

    @Test
    public void validateCurrencyCode_currencyPairInvalid(){
        final TradeDTO tradeDTO = new TradeDTO("PLUTO1","CCCYYY",null,"", tuesday,"","",
                "", monday, CS_ZURICH,"","","","");

        ResponseDTO dto = new ResponseDTO(tradeDTO,StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateCurrencyCode(dto);

        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(2);
        assertThat(validated.statusDTO.status).isEqualTo(INVALID);
        assertThat(validated.statusDTO.resons).contains("primary currency in a pair not valid");
        assertThat(validated.statusDTO.resons).contains("second currency in a pair not valid");
    }

    @Test
    public void validateCurrencyCode_stylNotSupported() {
        final TradeDTO tradeDTO = new TradeDTO("", "", null, "", monday, "", "",
                "", monday, CS_ZURICH, "", "XXX", "", "");

        ResponseDTO dto = new ResponseDTO(tradeDTO, StatusDTO.createStatus());
        final ResponseDTO validated = PureValidators.validateStyle(dto, asList("American", "European"));
        assertThat(validated).isNotNull();
        assertThat(validated.statusDTO).isNotNull();
        assertThat(validated.statusDTO.resons).hasSize(1);
        assertThat(validated.statusDTO.status).isEqualTo(INVALID);
    }

}