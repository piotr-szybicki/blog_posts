package com.cs.traiding.controllers;

import com.cs.traiding.controllers.datamodel.ResponseDTO;
import com.cs.traiding.controllers.datamodel.TradeDTO;
import com.cs.traiding.controllers.validators.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalTime;
import java.util.List;

import static java.time.Duration.ofMillis;
import static reactor.core.publisher.Flux.fromIterable;
import static reactor.core.publisher.Mono.just;

@RestController
public class Controller {

    @Autowired
    Validator validator;

    @PostMapping("/submit")
    public Flux<ResponseDTO> validateTrades(@RequestBody List<TradeDTO> trade){
        return validator.validate(fromIterable(trade));
    }

    @GetMapping("/echo")
    public Mono<String> echo(){
        return just("echo");
    }

    @RequestMapping(value = "/download", method = RequestMethod.GET, produces = "application/zip")
    public ResponseEntity download() throws IOException {
        InputStream inputStream = new FileInputStream(new File("C:\\Users\\pszybicki\\Desktop\\large.zip"));
        InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment","large.zip");
        return new ResponseEntity(inputStreamResource, headers, HttpStatus.OK);
    }

}
