package com.cs.traiding.controllers.so.layout;

import java.awt.*;

public class ScreenElement {
    public void draw(Canvas canvas) {
    }
}

