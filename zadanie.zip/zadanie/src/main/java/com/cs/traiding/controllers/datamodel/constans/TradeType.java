package com.cs.traiding.controllers.datamodel.constans;

public enum TradeType {
    Spot, Forward, VanillaOption
}