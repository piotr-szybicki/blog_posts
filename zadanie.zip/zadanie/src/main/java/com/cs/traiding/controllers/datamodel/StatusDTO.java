package com.cs.traiding.controllers.datamodel;

import com.cs.traiding.controllers.datamodel.constans.TradeStatus;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static com.cs.traiding.controllers.datamodel.constans.TradeStatus.INVALID;
import static com.cs.traiding.controllers.datamodel.constans.TradeStatus.VALID;

@NoArgsConstructor(force = true)
public class StatusDTO {

    public TradeStatus status = VALID;
    public List<String> resons = new ArrayList<>();

    public void changeStatusToInvalidIfErrorsExist() {
        if (resons.isEmpty()) {
            this.status = VALID;
        } else {
            this.status = INVALID;
        }
    }

    public void addRreason(String reason) {
        resons.add(reason);
    }

    public static StatusDTO createStatus() {
        return new StatusDTO();
    }
}
