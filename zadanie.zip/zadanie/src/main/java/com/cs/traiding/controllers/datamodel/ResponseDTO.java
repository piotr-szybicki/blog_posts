package com.cs.traiding.controllers.datamodel;

import com.cs.traiding.controllers.datamodel.constans.TradeType;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import static io.netty.util.internal.StringUtil.isNullOrEmpty;
import static java.util.Arrays.stream;

@AllArgsConstructor
@NoArgsConstructor(force = true)
public class ResponseDTO {

    public final TradeDTO tradeDTO;
    public final StatusDTO statusDTO;

    public boolean isType(TradeType... types){
        return stream(types).anyMatch(type -> type.equals(this.tradeDTO.type));
    }

    public LocalDate tradeDate(){
        return this.tradeDTO.tradeDate;
    }

    public LocalDate valueDate(){
        return this.tradeDTO.valueDate;
    }

    public String counterParty(){
        return this.tradeDTO.customer;
    }

    public String currencyPairPrimary(){
        return this.tradeDTO.ccyPair.substring(0, 3);
    }

    public String currencyPairSecondary(){
        return this.tradeDTO.ccyPair.substring(3);
    }

    public String payCcyOrEmpty(){
        if(isNullOrEmpty(this.tradeDTO.payCcy)){
            return "";
        }
        return this.tradeDTO.payCcy;
    }

    public String premiumCcyOrEmpty(){
        if(isNullOrEmpty(this.tradeDTO.premiumCcy)){
            return "";
        }

        return this.tradeDTO.premiumCcy;
    }

    public String styleOrEmpty() {
        if(isNullOrEmpty(this.tradeDTO.style)){
            return "";
        }

        return this.tradeDTO.style;
    }
}
