package com.cs.traiding.controllers;


import com.cs.traiding.controllers.datamodel.constans.Entity;
import com.cs.traiding.controllers.datamodel.TradeDTO;
import com.cs.traiding.controllers.datamodel.constans.TradeType;
import com.cs.traiding.controllers.validators.Validator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;

import static java.time.LocalDate.now;
import static java.util.Arrays.asList;
import static org.springframework.test.web.reactive.server.WebTestClient.bindToApplicationContext;
import static reactor.core.publisher.Flux.just;

@RunWith(SpringRunner.class)
@WebFluxTest
public class ControllerIntegrationTest {

    @Autowired
    private ApplicationContext context;

    @MockBean
    private Validator validator;

    private WebTestClient webClient;

    @Test
    public void testEndpoint_validateEcho() throws Exception {
        webClient = bindToApplicationContext(context).build();

        webClient
                .get().uri("/echo")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk();
    }

    @Test
    public void testEndpoint_validateDatamodel() throws Exception {
        webClient = bindToApplicationContext(context).build();

        webClient
                .post().uri("/submit")
                .syncBody(createList())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus()
                .isOk();
    }

    private List<TradeDTO> createList() {
        TradeDTO dto = new TradeDTO("PLUTO1","EURUSD", TradeType.VanillaOption,"BUY",now(),
                "1000000.00","1120000.00","1.12", now(), Entity.CS_ZURICH,
                "Johann Baumfiddler", "", "EUR","USD");

        return asList(dto);
    }
}