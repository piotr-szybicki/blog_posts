package com.cs.traiding.controllers.datamodel.constans;

public enum TradeStatus {
    VALID, INVALID
}
