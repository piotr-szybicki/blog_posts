package com.cs.traiding.controllers.datamodel;

import com.cs.traiding.controllers.datamodel.constans.Entity;
import com.cs.traiding.controllers.datamodel.constans.TradeType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor(force = true)
@AllArgsConstructor
public class TradeDTO {

    @JsonProperty(required = true)
    public final String customer;

    @JsonProperty(required = true)
    public final String ccyPair;

    @JsonProperty(required = true)
    public final TradeType type;

    @JsonProperty(required = true)
    public final String direction;

    @JsonProperty(required = true)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    public final LocalDate tradeDate;

    @JsonProperty(required = true)
    public final String amount1;

    @JsonProperty(required = true)
    public final String amount2;

    @JsonProperty(required = true)
    public final String rate;

    @JsonProperty(required = true)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    public final LocalDate valueDate;

    @JsonProperty(required = true)
    public final Entity legalEntity;

    @JsonProperty(required = true)
    public final String trader;

    @JsonProperty(required = false)
    public final String style;

    @JsonProperty(required = false)
    public final String payCcy;

    @JsonProperty(required = false)
    public final String premiumCcy;

    @Override
    public String toString() {
        return "TradeDTO{" +
                "customer='" + customer + '\'' +
                '}';
    }
}
